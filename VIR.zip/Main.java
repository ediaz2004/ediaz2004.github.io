import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    Scanner key = new Scanner(System.in);
    System.out.println("Hello! Welcome to the Current Calculator!");
    TheStart();
    }

  public static void TheStart(){
    Scanner key = new Scanner(System.in);
    System.out.println("What do you want to calculate?");
    System.out.println("Type 1 to convert megavolts to volts.");
    System.out.println("Type 2 to convert millivolts to volts.");
    System.out.println("Type 3 to convert from microvolts to volts.");
    System.out.println("Type 4 to convert from kilovolts to volts.");
    System.out.println("Type 5 to go straight to solving your current.");
    int r = key.nextInt();
    if(r==1){
      System.out.println("What is your current Voltage?");
      double s = key.nextDouble();
      MegaVolt(s);
    }
    else if(r==2){
    System.out.println("What is your current Voltage?");
      double o = key.nextDouble();
      MilliVolt(o);
    }
    else if(r==3){
    System.out.println("What is your current Voltage?");
      double f = key.nextDouble();
      MicroVolt(f);
    }
    else if(r==4){
    System.out.println("What is your current Voltage?");
      double h = key.nextDouble();
      KiloVolt(h);
    }
    else
      Function();
  } 

  public static void Function(){
    Scanner key = new Scanner(System.in);
    System.out.println("Please input the following variables in order one by one, using the enter key after each input:");
    System.out.println("Volage(V), Resistance(R), and the percentage value of Tolerance(T) in decimal form.");
    double V = key.nextDouble();
    double R = key.nextDouble();
    double T = key.nextDouble();
    System.out.println(" ");
    System.out.println("I = "+Current(V,R)+" Amps");
    System.out.println(" ");
    CurrentHigh(Current(V,R), T);
    System.out.println(" ");
    CurrentLow(Current(V,R), T);
    System.out.println(" ");
    System.out.println("Do you want to calculate another current? (1 for Yes, 2 for No)");
    int A = key.nextInt();
    if(A==1)
    TheStart();
    else
    System.out.println("Bye!");
  }

  public static double MegaVolt(double x){
     System.out.println(" ");
     System.out.println("Your Voltage is "+x*1000000+" Volts. Please input this number for Voltage in the next step.");
     Function();
     return (x*1000000);
  }

  public static double MilliVolt(double d){
     System.out.println(" ");
     System.out.println("Your Voltage is "+d/1000+" Volts. Please input this number for Voltage in the next step.");
     Function();
     return (d/1000);
  }

  public static double MicroVolt(double b){
     System.out.println(" ");
     System.out.println("Your Voltage is "+b/1000000+" Volts. Please input this number for Voltage in the next step.");
     Function();
     return (b/1000000);
  }

  public static double KiloVolt(double w){
     System.out.println(" ");
     System.out.println("Your Voltage is "+w*1000+" Volts. Please input this number for Voltage in the next step.");
     Function();
     return (w*1000);
  }

  public static double Current(double v, double r){
    return (v/r);
  }

  public static void CurrentHigh(double x, double y){
    System.out.println("Current with highest tolerance = "+((x*y)+x)+" Amps");
  }

  public static void CurrentLow(double a, double b){
    System.out.println("Current with lowest tolerance = "+(a-(a*b))+" Amps");
  }
}